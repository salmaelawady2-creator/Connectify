# Connectify landing page

Static landing page for Connectify, hosted on GitHub Pages.

## Setup
1. Get a free access key at https://web3forms.com (enter the email that should receive signups).
2. In `index.html`, replace `YOUR_ACCESS_KEY_HERE` with your key.
3. Replace `hello@connectify.com` and the `#` social links in the Contact section.
4. Repo **Settings > Pages > Deploy from a branch > main / (root) > Save**.

The site goes live at `https://YOUR-USERNAME.github.io/REPO-NAME/`.
